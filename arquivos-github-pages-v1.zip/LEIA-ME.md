# Prévia pública para recrutadores

Esta pasta contém apenas a versão estática e somente para leitura do projeto. Não inclui servidor Python, contas, senhas, cadastros ou dados persistentes.

## Publicar no GitHub Pages

1. Use o repositório público `VSfalcon2008/VSfalcon2008` ou escolha outro repositório público.
2. Envie para a raiz do repositório apenas `index.html`, `styles.css`, `app.js` e `logo-industria.png` desta pasta.
3. No repositório, abra **Settings → Pages** e escolha a publicação pela branch `main`, pasta `/(root)`.
4. Após a publicação no repositório indicado, o endereço será `https://vsfalcon2008.github.io/VSfalcon2008/?modo=demo`.
5. Envie esse endereço pelo WhatsApp. A página abre direto como convidado e oculta o login.

O GitHub Pages publica sites estáticos. Essa prévia é para apresentar o layout e as telas; aprovações de usuário, gravação compartilhada e API Python só funcionam na versão hospedada com backend. Em contas GitHub Free, o repositório para Pages deve ser público e o conteúdo do site fica acessível na internet. Consulte [a documentação oficial do GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site).
